---
name: tclaw-asr
description: Microphone capture and AI services cluster ASR WebSocket streaming.
version: 0.1.0
author: tclaw
tags: [tclaw, asr]
---

# tclaw-asr

Sidecar streams PCM frames to AI services cluster ASR (`WS /api/v1/asr/stream`).
