---
name: tclaw-camera
description: Local camera snap and screen capture via tclaw-media sidecar.
version: 0.1.0
author: tclaw
tags: [tclaw, camera]
---

# tclaw-camera

Windows capture via sidecar (`:9876`). Requires connected session.
