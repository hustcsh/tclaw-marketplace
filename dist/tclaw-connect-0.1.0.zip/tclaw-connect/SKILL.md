---
name: tclaw-connect
description: Connection gate — only allow meeting/camera when AI services cluster bind succeeded.
version: 0.1.0
author: tclaw
tags: [tclaw, connect]
---

# tclaw-connect

Rejects meeting and camera commands until `ConnectionSessionState` is `connected` or `meeting_active`.

Bind flow is handled by tclaw-control via `POST /tclaw/bind` on tclaw-connect (`:9875`).
