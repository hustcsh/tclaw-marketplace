---
name: tclaw-control-conversation
description: List, create, rename, delete conversations and load history via AI-services personal API.
version: 0.1.0
author: tclaw
tags: [tclaw, control, conversation]
---

# tclaw-control-conversation

控制端 agent 的对话历史管理 skill，对接 AI-services personal `/api/v1/conversations*`。

## 工具

| 工具 | 方法 | 端点 | 卡片 |
|------|------|------|------|
| `conversation_list` | GET | `/api/v1/conversations` | `conversation_list` |
| `conversation_create` | POST | `/api/v1/conversations` | `conversation_created` |
| `conversation_rename` | PATCH | `/api/v1/conversations/{id}` | `conversation_created` |
| `conversation_delete` | DELETE | `/api/v1/conversations/{id}` | — |
| `conversation_history` | GET | `/api/v1/conversations/{id}/messages` | `conversation_history` |

## 与对话流的关系

- 本 skill 只管理"会话元数据"（标题、列表、历史）
- 用户在对话框输入的新消息由 ZeroClaw agent loop 直接处理（`/ws/chat?agent=tclaw-control`），agent 决策是否调用 schedule/todo/meeting/screenshare 工具
- 历史消息落库仍由 AI-services personal 的 `POST /api/v1/conversations/{id}/messages` 完成（控制端 UI 在收到 `done` 事件后调用，落库不在 agent loop 内）
