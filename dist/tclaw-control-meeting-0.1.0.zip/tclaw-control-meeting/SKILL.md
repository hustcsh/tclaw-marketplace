---
name: tclaw-control-meeting
description: Orchestrate meeting start/end from the control side. Calls tclaw body sidecar and AI-services meetings.
version: 0.1.0
author: tclaw
tags: [tclaw, control, meeting]
---

# tclaw-control-meeting

控制端 agent 的会议编排 skill。会中硬件控制（布局/ASR/纪要）由主体 `tclaw` agent 承载，本 skill 只负责"启动/结束"。

## 工具

| 工具 | 方法 | 端点 | 卡片 |
|------|------|------|------|
| `meeting_start` | POST | `{{tclaw_sidecar_url}}/meeting/start` | `meeting_started` |
| `meeting_end` | POST | `{{tclaw_sidecar_url}}/meeting/end` | — |
| `meeting_status` | GET | `{{ai_services_personal_url}}/api/v1/meetings/sessions/active` | `meeting_status` |

## meeting_type

| meeting_type | ASR display | LLM minutes |
|--------------|-------------|-------------|
| transcript_only | yes | no |
| standard | yes | yes |
| executive | yes | yes (structured) |

## schedule_id 联动

`meeting_start` 传 `schedule_id` 时，主体 sidecar 会：
1. 从 AI-services personal 拉取该日程的 `start_at` / `end_at`
2. 同步到主体视频区上方时间段显示（title 下方，计时器前面）

## 跨机部署

- `tclaw_sidecar_url` 由 [tclaw-control] 配置段注入（`http://<tclaw-ip>:9876`）
- 主体 sidecar 已绑定 `0.0.0.0:9876`，支持跨机访问
- 控制端 agent 也可通过 ZeroClaw gateway 远程调主体 agent（`/ws/chat?agent=tclaw`），但启动会议走 sidecar 直连最短路径
