---
name: tclaw-control-schedule
description: Create, list, update, delete personal schedules via AI-services personal API.
version: 0.1.0
author: tclaw
tags: [tclaw, control, schedule]
---

# tclaw-control-schedule

控制端 agent 的日程类 skill，对接 AI-services personal `/api/v1/schedules*`。

## 工具

| 工具 | 方法 | 端点 | 卡片 |
|------|------|------|------|
| `schedule_create` | POST | `/api/v1/schedules/parse` | `schedule_created` |
| `schedule_list` | GET | `/api/v1/schedules?from=&to=` | `schedule_list` |
| `schedule_update` | PATCH | `/api/v1/schedules/{id}` | `schedule_created` |
| `schedule_delete` | DELETE | `/api/v1/schedules/{id}` | — |

## 时间格式

- 所有 `start_at` / `end_at` 使用 ISO 8601 带时区，如 `2026-08-07T15:00:00+08:00`
- 后端 `parseTime` 使用 `time.ParseInLocation(layout, s, time.Local)`（Asia/Shanghai）

## 与会议的联动

用户说"从日程开始会议"时，由 LLM 决策先 `schedule_list` 拿到 `schedule_id`，再调用 `tclaw-control-meeting.meeting_start` 并传 `schedule_id`。
