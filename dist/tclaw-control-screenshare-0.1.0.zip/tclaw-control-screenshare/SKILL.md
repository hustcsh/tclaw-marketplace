---
name: tclaw-control-screenshare
description: Start/stop screen share from control side to tclaw body via WebRTC. Emits ui_action to drive WebView.
version: 0.1.0
author: tclaw
tags: [tclaw, control, screenshare]
---

# tclaw-control-screenshare

控制端 agent 的投屏共享 skill。WebRTC 视频流由 WebView 原生 JS 处理（`getDisplayMedia` + `RTCPeerConnection`），本 skill 只负责拿 cast_code 并发 `ui_action` 联动 UI。

## 工具

| 工具 | 方法 | 端点 | 卡片 / UI 联动 |
|------|------|------|---------------|
| `screenshare_start` | GET | `{{ai_services_personal_url}}/api/v1/meetings/castcode/lookup` | `screenshare_connect` → `ui_action(screenshare_connect)` |
| `screenshare_stop` | POST | `{{tclaw_screen_receiver_url}}/screenshare/end` | `ui_action(screenshare_disconnect)` |

## 链路

```
用户对话："共享屏幕"
  → agent 调 screenshare_start(meeting_id)
  → AI-services meetings 返回 { cast_code, tclaw_ip, screen_receiver_url }
  → agent loop 发 tool_result(screenshare_connect, payload={signaling_url, cast_code, tclaw_ip})
  → control-runtime 适配层把 payload 转为 ui_action(screenshare_connect) 推给 WebView
  → WebView 调 getDisplayMedia + RTCPeerConnection → screen-receiver(:9878) → 主体 ui
```

## 并发策略

由主体 `screen-receiver` 仲裁（`TCLAW_SCREENSHARE_CONCURRENCY_POLICY`）：
- `reject`（默认）：第二个共享者被拒绝
- `replace`：后者顶掉前者

## 跨机部署

- `tclaw_screen_receiver_url` 由 [tclaw-control] 配置段注入（`http://<tclaw-ip>:9878`）
- screen-receiver 已绑定 `0.0.0.0:9878`，支持跨机访问
- WebRTC P2P 链路在 LAN 内直连，不走 AI-services
