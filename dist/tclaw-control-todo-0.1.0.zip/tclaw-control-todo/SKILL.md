---
name: tclaw-control-todo
description: Create, list, update, complete personal todos via AI-services personal API.
version: 0.1.0
author: tclaw
tags: [tclaw, control, todo]
---

# tclaw-control-todo

控制端 agent 的待办类 skill，对接 AI-services personal `/api/v1/todos*`。

## 工具

| 工具 | 方法 | 端点 | 卡片 |
|------|------|------|------|
| `todo_create` | POST | `/api/v1/todos/parse` | `todo_created` |
| `todo_list` | GET | `/api/v1/todos?meeting_id=` | `todo_list` |
| `todo_complete` | PATCH | `/api/v1/todos/{id}/status` | `todo_created` |
| `todo_update` | PATCH | `/api/v1/todos/{id}` | `todo_created` |

## 与会议的联动

会议进行中，`todo_create` 可附带 `meeting_id`，将待办关联到当前会议；会议纪要生成时也会从同一 `meeting_id` 拉取待办。
