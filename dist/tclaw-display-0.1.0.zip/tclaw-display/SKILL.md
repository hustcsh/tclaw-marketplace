---
name: tclaw-display
description: Dynamic display compositor — presets, PiP, ASR/minutes visibility.
version: 0.1.0
author: tclaw
tags: [tclaw, display]
---

# tclaw-display

Controls `DisplayCompositorState` on sidecar `:9876`. Natural language maps to layout APIs.

Presets: `camera_fullscreen`, `screenshare_pip`, `screenshare_pip_minutes`, `meeting_default`.
