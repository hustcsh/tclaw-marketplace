---
name: tclaw-meeting
description: Start and end meetings with meeting_type-driven minutes policy.
version: 0.1.0
author: tclaw
tags: [tclaw, meeting]
---

# tclaw-meeting

| meeting_type | ASR display | LLM minutes |
|--------------|-------------|-------------|
| transcript_only | yes | no |
| standard | yes | yes |
| executive | yes | yes (structured) |

Use `meeting_start` before camera/ASR. Requires connected bind state.
