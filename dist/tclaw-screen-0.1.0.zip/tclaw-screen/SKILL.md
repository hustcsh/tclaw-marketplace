---
name: tclaw-screen
description: Screen sharing via WebRTC screen-receiver.
version: 0.1.0
author: tclaw
tags: [tclaw, screen]
---

# tclaw-screen

Controls `tclaw-screen-receiver` on `:9878`. When share starts, sidecar should set `base=screenshare`.
